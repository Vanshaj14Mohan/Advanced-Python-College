import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.title("Car data App")

data = pd.read_excel("E:\Advanced Python\ESE2\Cardata.xlsx")

st.subheader("5 rows of the dataset")
st.write(data.head(5))





